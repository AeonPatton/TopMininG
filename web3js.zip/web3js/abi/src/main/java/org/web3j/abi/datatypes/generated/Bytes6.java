package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.web3j.codegen.AbiTypesGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes6 extends Bytes {
    public static final Bytes6 DEFAULT = new Bytes6(new byte[6]);

    public Bytes6(byte[] value) {
        super(6, value);
    }
}
